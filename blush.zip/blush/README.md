# Blush – Retail & Wholesale Management (Salesforce Phase 1)

Implementation of the *Blush Mini Project – Fresher Assignment* in the Developer org **Org2**
(`nkarankalj2005.c70606f92d83@agentforce.com`). Standard objects are used wherever possible; Apex is used only
where declarative tools cannot meet the requirement (cross-object matching/conversion, price book maintenance,
GST line calculation, nightly batch, PDF generation).

## 1. What was built (by requirement)

| Req | Solution | Key components |
|---|---|---|
| **A. Customers & sales** | Lead → Account/Contact → Opportunity → Order. Record types **Retail / Wholesale** on Account, Opportunity and Order. Opportunity captures customer first/last name, email, phone (and company for wholesale). On save, the customer is resolved automatically: existing Contact (email/phone) → linked; one matching unconverted Lead → **converted** (no extra opportunity); no match → **Account + Contact created** with the matching record type. Conflicts are flagged *Needs Review*. | `OpportunityTrigger`, `OpportunityCustomerService`, fields `Customer_*__c`, `Lead_Processing_Status__c`, `Processing_Message__c`, validation rules `Customer_Details_Required`, `Account_Matches_Channel`, `Pricebook_Matches_Channel` |
| **B. Promotions** | Standard **Campaigns** + Campaign Members; list view **Current Month Campaigns**; report *Current Month Campaigns* (campaigns overlapping this month) on the Marketing dashboard. | `Campaign.Current_Month_Campaigns` list view, Blush Marketing Reports |
| **C. Catalogue & pricing** | Product fields **Category** (Garments/Jewellery), **Available for Retail / Wholesale**, **Base (Retail) Price**. Two price books (*Blush Retail*, *Blush Wholesale*, identified by `Pricebook2.Channel__c`). A product trigger creates/updates/deactivates entries automatically: Retail = base price, Wholesale = base − 30%. Opportunities and Orders default to the channel price book and validation rules block the wrong one. | `ProductTrigger`, `ProductPricingService`, `BlushChannel` |
| **D. Follow-up reminders** | Nightly **Batch + Schedulable** Apex (01:00). Open opportunity + incomplete Task (or Event not marked *Completed*) dated within the last 5 days → one reminder Task for the opportunity owner. `Follow_Up_Reminder_Sent__c` guarantees max one reminder per opportunity. | `OpportunityFollowUpBatch` (scheduled job *Blush Opportunity Follow-up Reminders*), `Event_Completed__c` |
| **E. Commission** | Formula fields: **Effective Order Amount** = Amount Received − GST; **Commission** = 1% if ≤ Rs.1,000, else flat Rs.30. | `Order.Effective_Order_Amount__c`, `Order.Commission__c` |
| **F. Order controls** | Sales users edit orders while processing. Once **Payment Status = Paid**, validation rule `Paid_Order_Locked` blocks order edits and the Order Product trigger blocks adding/changing/removing lines. Admins with custom permission *Blush: Edit Paid Orders* can correct. | `Paid_Order_Locked`, `OrderItemService`, custom permission `Blush_Edit_Paid_Orders` |
| **G. Invoice & GST** | Per line: discount, taxable value, GST rate (Jewellery 3%; Garments 5%, 12% when discounted unit price > Rs.1,000), CGST+SGST (Maharashtra billing) or IGST (other states), net price = (Unit Price − Discount) × Qty + GST. Order totals are **roll-up summary** fields. Discount > 10% → native **Approval Process** *Blush Discount Approval*; orders cannot be Activated/Paid or invoiced until approved. **Generate Invoice** button renders a Visualforce PDF, assigns invoice number `INV-<Order No>`, saves it as a File on the Order (re-generation adds a new version). **Preview Invoice** opens the PDF without saving. | `OrderItemTrigger`, roll-ups on Order, `Discount_Approval_Required`, `Blush_Discount_Approval`, `BlushInvoiceController`, pages `BlushInvoicePdf`, `BlushGenerateInvoice` |
| **H. Reports & dashboards** | 19 reports in *Blush Sales Reports* / *Blush Marketing Reports* on 4 custom report types; dashboards **Blush Retail Dashboard**, **Blush Wholesale Dashboard**, **Blush Marketing Dashboard** (see §3). | `reportTypes/`, `reports/`, `dashboards/` |
| **I. Users & app** | Lightning app **Blush** (default app for System Administrator, Standard User and Marketing User profiles). Permission sets **Blush Sales**, **Blush Marketing**, **Blush Admin**; public groups *Blush Sales Team* / *Blush Marketing Team* control report & dashboard folder access. Users: **Priya Deshmukh** (Sales rep, Salesforce licence, Standard User + Blush Sales) and **Rohan Mehta** (Marketing, Salesforce licence + Marketing User feature licence, Marketing User profile + Blush Marketing). The admin (Nimisha) is the Sales Manager/approver with Blush Admin. | `applications/Blush.app`, `permissionsets/`, `profiles/` |
| **J. Testing** | 60 Apex tests, all passing; **97% org-wide coverage** for Blush code (all triggers, pricing, order, batch and invoice classes 100%; `OpportunityCustomerService` 94%, `OrderService` 97%, `BlushChannel` 96% – the uncovered lines are DML-failure rollback branches and the production-only standard price book lookup). Tests cover positive, negative, boundary and bulk (200 products, 100+ opportunities) cases and run as a real Sales user for the paid-order lock. | `*Test.cls`, `BlushTestFactory` |

## 2. Data model

* **Store__c** (custom): name, code (unique, external id), address, state, GSTIN, phone, active. Order → Store lookup.
* **Account / Opportunity / Order** record types *Retail* and *Wholesale* (+ `Channel__c` formula = record type).
* **Opportunity**: `Customer_First_Name__c`, `Customer_Last_Name__c`, `Customer_Email__c`, `Customer_Phone__c`, `Customer_Company__c`, `Lead_Processing_Status__c` (Pending / Processed / Needs Review / Not Required), `Processing_Message__c`, `Follow_Up_Reminder_Sent__c`. Business process *Blush Sales Process*.
* **Product2**: `Category__c`, `Retail_Available__c`, `Wholesale_Available__c`, `Base_Price__c`. **Pricebook2**: `Channel__c`.
* **Order**: `Store__c`, `Sales_Representative__c` (User), `Payment_Mode__c`, `Payment_Status__c`, `Amount_Received__c`, `Discount_Approval_Status__c`, `Invoice_Number__c` (unique), `Invoice_Date__c`, `Invoice_Generated__c`; roll-ups `Subtotal__c`, `Discount_Total__c`, `Taxable_Amount__c`, `CGST_Total__c`, `SGST_Total__c`, `IGST_Total__c`, `Tax_Total__c`, `Total_Amount_Payable__c`, `Max_Line_Discount_Percent__c`; formulas `Effective_Order_Amount__c`, `Commission__c`, `Channel__c`, `Customer_Name__c`, `Sales_Rep_Name__c`.
* **OrderItem**: `Discount_Percent__c` (input) and stored results `Gross_Amount__c`, `Unit_Discount__c`, `Discount_Amount__c`, `Taxable_Amount__c`, `GST_Rate__c`, `CGST/SGST/IGST_Amount__c`, `Tax_Amount__c`, `Net_Price__c`; reporting formulas `Product_*__c`, `Channel__c`, `Assumed_Cost__c`, `Assumed_Revenue__c`, `Assumed_Profit__c`.

## 3. Reports and dashboards

*Blush Sales Reports*: Monthly Commission by Sales Rep · Top Sales Reps by Commission (Monthly) · Top 3 Sales Reps – This Month · Quarterly Revenue Statement (cost Rs.100, retail Rs.200, wholesale Rs.140 per unit, before GST) · Monthly Order Report · Retail vs Wholesale Monthly Comparison (matrix with *Previous Month Amount* and *Change* via `PREVGROUPVAL`) · Total GST Payable · Top 10 Products by Net Sales Quantity · Retail/Wholesale Monthly Sales, Sales by Rep, Top Products.

*Blush Marketing Reports*: Current Month Campaigns · Campaigns by Status · Campaign Responses and Leads · Leads by Status · Leads by Source and Conversion.

Dashboards (run as the admin): **Retail** and **Wholesale** – monthly sales, monthly order count, this vs previous month table, top 10 products, sales by rep, top 3 reps by commission this month, retail vs wholesale by month, GST payable. **Marketing** – current month campaigns, campaigns by status, responses and leads per campaign, leads by status, leads by source/conversion.

## 4. Sample data (loaded by `scripts/apex`)

20 products (10 Garments, 10 Jewellery; 2 wholesale-only, 3 retail-only), 2 stores (Pune, Mumbai), 5 campaigns, 8 leads,
7 opportunities (4 lead conversions incl. one matched on a differently formatted phone, 2 new customers, 1 *Needs Review*
email/phone conflict), 10 customers (Maharashtra, Gujarat, Karnataka, Madhya Pradesh), 22 orders July–October 2026
(20 paid; **D01** 15% discount pending approval; **D02** 12% discount approved then paid; **D03** open draft),
3 reminder tasks created by the batch, invoice PDFs `docs/invoices/` (INV-00000100 intra-state retail, INV-00000101 IGST retail,
INV-00000115 wholesale with 10% discount, INV-00000120 approved 12% discount, IGST).

## 5. Assumptions / clarifications for the mentor

1. **Product data** – the trainer's product sheet was not available; 20 representative products were created. Base price = retail price.
2. **Sales Representative** – the rep who handled the customer is the Opportunity owner (else the Account owner, else the creator), stored on `Order.Sales_Representative__c`; commission reports group by it.
3. **Customer matching** – email (case-insensitive, trimmed) or phone (last 10 digits). An existing Contact wins over a Lead (prevents duplicates for repeat customers). Several matching leads/contacts, or a match in the other channel → *Needs Review*, nothing is converted automatically.
4. **Retail customers** are modelled as Business Accounts with a Contact (Person Accounts not enabled).
5. **Garment GST threshold** – applied to the **discounted unit price** (Rs.1,000 exactly → 5%, above → 12%).
6. **Place of supply** – customer billing state Maharashtra (or blank) → CGST+SGST; any other state → IGST.
7. **Discount approval** – any line discount > 10% (highest line discount on the order). Approver = Sales Manager (admin user). Changing a >10% line after a decision clears the approval.
8. **Commission** – on the amount actually received minus GST; unpaid orders have commission 0. Partial payments use the amount received.
9. **Reminder window** – activity date between run date − 5 days and run date (inclusive); an Event counts as incomplete until *Completed (Events)* is ticked. One reminder per opportunity for its lifetime.
10. **Reporting date** – Order Start Date (`EffectiveDate`); commission, GST and product reports include paid orders only.
11. **Currency display** – the org currency is USD/en_US, so the UI shows "$"; amounts are rupees and the invoice prints "Rs.". Change *Company Information → Currency Locale* to *English (India) – INR* if desired.
12. **Licences** – the Developer org has only one free Marketing User feature licence; it is assigned to the Marketing user (the admin borrowed it temporarily to load sample campaigns).

## 6. Demo walkthrough

1. App Launcher → **Blush**.
2. *Products*: open *Oxidised Jhumka* → Related → Price Book Entries (Retail 249, Wholesale 174.30). Untick *Available for Wholesale* → wholesale entry becomes inactive.
3. *Opportunities* → New → Retail → enter a customer name + an email of an open lead (e.g. *pooja.nair@example.com*) → save → the lead is converted and the opportunity linked (see *Customer Details* section).
4. *Orders*: open order dated 27-Oct (D03) → add products with *Discount %* → GST columns fill in. Set a discount of 15% → mark Paid → blocked until approved → *Submit for Approval*.
5. Open a paid order (e.g. 14-Oct, Shaikh Garments) → **Generate Invoice** → PDF saved under Files; as Priya, try to edit → blocked.
6. *Tasks*: the three *Follow-up reminder* tasks; Setup → Scheduled Jobs shows the nightly job.
7. *Dashboards* → Blush Sales Dashboards / Blush Marketing Dashboards.

## 7. Deploy / reload

```bash
sf project deploy start -o <org> -d force-app            # metadata (run tests with -l RunLocalTests in production)
sf org assign permset -n Blush_Admin -o <org>
sf apex run -o <org> -f scripts/apex/01-users.apex       # users + permission sets
sf apex run -o <org> -f scripts/apex/02-catalog.apex     # price books, stores, products
sf apex run -o <org> -f scripts/apex/flag-admin-marketing.apex
sf apex run -o <org> -f scripts/apex/03-campaigns-leads.apex
sf apex run -o <org> -f scripts/apex/04-sales.apex       # opportunities, activities, orders, approvals
sf apex run -o <org> -f scripts/apex/flag-marketing-user.apex
sf apex run -o <org> -f scripts/apex/05-schedule-reminders.apex
sf apex run -o <org> -f scripts/apex/06-groups.apex      # report/dashboard folder sharing
sf apex run test -o <org> -l RunLocalTests -c -w 20
```
