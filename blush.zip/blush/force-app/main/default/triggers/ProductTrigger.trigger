trigger ProductTrigger on Product2(after insert, after update) {
    ProductPricingService.syncPricebookEntries(Trigger.new, Trigger.isUpdate ? Trigger.oldMap : null);
}
