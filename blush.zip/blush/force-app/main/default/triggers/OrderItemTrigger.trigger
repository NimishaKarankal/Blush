trigger OrderItemTrigger on OrderItem(before insert, before update, before delete, after insert, after update) {
    if (Trigger.isBefore) {
        if (Trigger.isDelete) {
            OrderItemService.beforeDelete(Trigger.old);
        } else {
            OrderItemService.beforeSave(Trigger.new);
        }
    } else {
        OrderItemService.resetApprovalIfNeeded(Trigger.new, Trigger.isUpdate ? Trigger.oldMap : null);
    }
}
