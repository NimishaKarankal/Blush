trigger OpportunityTrigger on Opportunity(before insert, after insert, after update) {
    if (Trigger.isBefore) {
        OpportunityCustomerService.applyDefaults(Trigger.new);
    } else {
        OpportunityCustomerService.processPending(Trigger.new);
    }
}
