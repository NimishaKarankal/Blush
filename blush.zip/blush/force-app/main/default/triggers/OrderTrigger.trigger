trigger OrderTrigger on Order(before insert, before update, after update) {
    if (Trigger.isBefore) {
        OrderService.applyDefaults(Trigger.new, Trigger.isUpdate ? Trigger.oldMap : null);
    } else {
        OrderService.recalculateOnCustomerChange(Trigger.new, Trigger.oldMap);
    }
}
